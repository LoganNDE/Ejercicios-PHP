<?php
    define('PROJECT_ROOT', __DIR__);
?>